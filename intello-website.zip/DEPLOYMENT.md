# Intello Cyber Technologies Static Website

This is a statically generated website for Intello Cyber Technologies. 

## Form Handling

This website uses Formspree for form handling. Please ensure you've updated the Formspree IDs in:

1. client/src/components/ContactFormWithCalendly.tsx
2. client/src/components/AssessmentRequestForm.tsx

## Deployment Instructions

You can deploy this static website to any of the following platforms:

### Vercel (Recommended)
1. Connect your GitHub repository
2. Import the project
3. Deploy

### Netlify
1. Connect your GitHub repository or upload the dist folder
2. No additional configuration needed - _redirects is already set up

### GitHub Pages
1. Push the dist folder to the gh-pages branch
2. Enable GitHub Pages in repository settings
3. Set the source to the gh-pages branch

### Azure Static Web Apps
1. Follow the steps in AZURE_DEPLOYMENT_GUIDE.md

### GoDaddy Web Hosting
1. Follow the steps in GODADDY_DEPLOYMENT_GUIDE.md
