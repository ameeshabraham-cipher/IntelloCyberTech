# Intello Cyber Technologies Static Website

## Important Note

This is a simplified static website placeholder created in Replit. Due to resource constraints, the full static website must be built locally.

## What Has Been Changed

1. Removed the Company Profile page from navigation
2. Removed the search functionality from the website

## How to Build the Full Website

Follow the instructions in STATIC_BUILD_INSTRUCTIONS.md to build the complete static website on your local machine.

## Deployment to GoDaddy

Follow the instructions in GODADDY_DEPLOYMENT_GUIDE.md to deploy the static website to GoDaddy hosting.

## Form Handling

This website uses Formspree for form handling. Please ensure you've updated the Formspree IDs in:

1. client/src/components/ContactFormWithCalendly.tsx
2. client/src/components/AssessmentRequestForm.tsx
